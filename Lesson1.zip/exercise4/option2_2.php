<?php

$year = 2018;

include 'option2_1.php';