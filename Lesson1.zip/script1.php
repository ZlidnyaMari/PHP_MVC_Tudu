<?php

$name = readline('Как Ваше имя?');

$age = readline('Напишите сколько Вам лет.');

echo "Вас зовут $name, Вам $age лет";
